package constants;

public class ConstantsClass {
	
	public static final String filePath = System.getProperty("user.dir")+"/src/main/resources/config.properties";
	public static final int implicitWaitTimeDuration = 10;
	public static final String excelFilePath = System.getProperty("user.dir") + "/src/test/resources/TestData.xlsx";
	public static final String addExpenseFile = System.getProperty("user.dir") +"/src/test/resources/Add_Expense_File.docx";
	

}
